<footer class="site-footer" role="contentinfo">
  <div class="wrap">
    <div class="footer-top">

      <!-- Brand -->
      <div>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
          <div class="logo-mark" aria-hidden="true">K</div>
          <span><?php bloginfo('name'); ?></span>
        </a>
        <p class="footer-brand-desc"><?php echo kvx_mod('footer_desc', 'Senior-level managed IT and security for businesses that run lean. No vendor commissions. No junior staff. No surprises.'); ?></p>
      </div>

      <!-- Services -->
      <div class="footer-col">
        <h4><?php esc_html_e('Services','klaravex'); ?></h4>
        <ul>
          <li><a href="/services/cloud-productivity/"><?php esc_html_e('Cloud &amp; Productivity','klaravex'); ?></a></li>
          <li><a href="/services/network-security/"><?php esc_html_e('Network &amp; Security','klaravex'); ?></a></li>
          <li><a href="/services/strategy-vcio/"><?php esc_html_e('Strategy &amp; vCIO','klaravex'); ?></a></li>
          <li><a href="/managed-it-plans/"><?php esc_html_e('Managed IT Plans','klaravex'); ?></a></li>
          <li><a href="/cyber-insurance-readiness/"><?php esc_html_e('Cyber-Insurance Readiness','klaravex'); ?></a></li>
        </ul>
      </div>

      <!-- Company -->
      <div class="footer-col">
        <h4><?php esc_html_e('Company','klaravex'); ?></h4>
        <ul>
          <li><a href="/about/"><?php esc_html_e('About Klaravex','klaravex'); ?></a></li>
          <li><a href="/how-our-ai-works/"><?php esc_html_e('How Our AI Works','klaravex'); ?></a></li>
          <li><a href="/blog/"><?php esc_html_e('Blog','klaravex'); ?></a></li>
          <li><a href="/knowledge-base/"><?php esc_html_e('Knowledge Base','klaravex'); ?></a></li>
        </ul>
      </div>

      <!-- Personal -->
      <div class="footer-col">
        <h4><?php esc_html_e('Personal','klaravex'); ?></h4>
        <ul>
          <li><a href="/personal/"><?php esc_html_e('Personal IT Help','klaravex'); ?></a></li>
          <li><a href="/job-hunt-tech-kit/"><?php esc_html_e('Job-Hunt Tech Kit','klaravex'); ?></a></li>
          <li><a href="/privacy-hardening/"><?php esc_html_e('Privacy Hardening','klaravex'); ?></a></li>
          <li><a href="/family-senior-tech/"><?php esc_html_e('Family &amp; Senior Tech','klaravex'); ?></a></li>
        </ul>
      </div>

    </div>

    <div class="footer-bottom">
      <p><?php echo kvx_mod('footer_legal', '&copy; ' . date('Y') . ' Klaravex LLC &mdash; United States'); ?></p>
      <p>
        <a href="/privacy-policy/"><?php esc_html_e('Privacy Policy','klaravex'); ?></a>
        &nbsp;&middot;&nbsp;
        <a href="/terms-of-service/"><?php esc_html_e('Terms of Service','klaravex'); ?></a>
      </p>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
