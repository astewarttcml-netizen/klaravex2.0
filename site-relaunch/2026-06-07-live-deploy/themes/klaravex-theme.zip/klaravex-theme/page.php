<?php get_header(); ?>
<main id="main" class="wrap" role="main" style="padding-top:80px;padding-bottom:80px;max-width:800px;">
  <?php while ( have_posts() ) : the_post(); ?>
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      <h1 style="font-family:var(--font-display);font-size:clamp(28px,4vw,52px);font-weight:800;letter-spacing:-0.03em;margin-bottom:32px;"><?php the_title(); ?></h1>
      <div class="entry-content" style="color:var(--dim);line-height:1.75;font-size:17px;">
        <?php the_content(); ?>
      </div>
    </article>
  <?php endwhile; ?>
</main>
<?php get_footer(); ?>
