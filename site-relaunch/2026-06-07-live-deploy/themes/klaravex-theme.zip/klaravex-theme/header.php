<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <link rel="profile" href="https://gmpg.org/xfn/11"/>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ANNOUNCE BAR -->
<div class="announce">
  <div class="wrap">
    <div class="announce-inner">
      <div class="announce-dot"></div>
      <span class="announce-badge">AI Live</span>
      <span class="announce-text"><strong>89% of IT issues</strong> resolved by AI — instantly, any hour, any day</span>
    </div>
  </div>
</div>

<!-- NAV -->
<nav class="site-nav" role="navigation" aria-label="<?php esc_attr_e('Primary Navigation','klaravex'); ?>">
  <div class="wrap">
    <div class="nav-inner">

      <!-- Logo -->
      <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
        <?php if ( has_custom_logo() ) :
            the_custom_logo();
        else : ?>
          <div class="logo-mark" aria-hidden="true">K</div>
          <span><?php bloginfo('name'); ?></span>
        <?php endif; ?>
      </a>

      <!-- Primary menu -->
      <?php wp_nav_menu([
          'theme_location' => 'primary',
          'menu_class'     => 'nav-menu',
          'container'      => false,
          'fallback_cb'    => function() { ?>
            <ul class="nav-menu">
              <li><a href="#services">Services</a></li>
              <li><a href="#how">How It Works</a></li>
              <li><a href="#cases">Results</a></li>
              <li><a href="#portal">Client Portal</a></li>
              <li><a href="#">About</a></li>
              <li><a href="#cta" class="nav-cta"><i class="ph ph-calendar-check"></i> Free Assessment</a></li>
            </ul>
          <?php },
      ]); ?>

      <!-- Mobile toggle -->
      <button class="nav-toggle" aria-label="<?php esc_attr_e('Toggle navigation','klaravex'); ?>" aria-expanded="false">
        <i class="ph ph-list"></i>
      </button>

    </div>
  </div>
</nav>
