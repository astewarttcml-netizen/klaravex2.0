<footer class="site-footer" role="contentinfo">
  <div class="wrap">
    <div class="footer-top">
      <div>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
          <div class="logo-mark" aria-hidden="true">K</div>
          <span><?php bloginfo('name'); ?></span>
          <span class="logo-personal"><?php esc_html_e('Personal','klaravex-personal'); ?></span>
        </a>
        <p class="footer-desc"><?php esc_html_e('Tech help for real people. Plain English, no judgment, no jargon. Remote and in-person across the US.','klaravex-personal'); ?></p>
      </div>
      <div class="footer-col">
        <h4><?php esc_html_e('Services','klaravex-personal'); ?></h4>
        <ul>
          <li><a href="/it-help-repairs/"><?php esc_html_e('IT Help &amp; Repairs','klaravex-personal'); ?></a></li>
          <li><a href="/family-senior-tech/"><?php esc_html_e('Family &amp; Senior Tech','klaravex-personal'); ?></a></li>
          <li><a href="/privacy-security/"><?php esc_html_e('Privacy &amp; Security','klaravex-personal'); ?></a></li>
          <li><a href="/ai-skills-coaching/"><?php esc_html_e('AI Skills Coaching','klaravex-personal'); ?></a></li>
          <li><a href="/job-hunt-tech-kit/"><?php esc_html_e('Job-Hunt Tech Kit','klaravex-personal'); ?></a></li>
          <li><a href="/solo-business-launch-kit/"><?php esc_html_e('Solo-Business Launch Kit','klaravex-personal'); ?></a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4><?php esc_html_e('Help','klaravex-personal'); ?></h4>
        <ul>
          <li><a href="<?php echo esc_url(home_url('/#cta')); ?>" data-chat-open="booking"><?php esc_html_e('Book a session','klaravex-personal'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/#pricing')); ?>"><?php esc_html_e('Pricing','klaravex-personal'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/faq/')); ?>"><?php esc_html_e('FAQ','klaravex-personal'); ?></a></li>
          <li><a href="<?php echo esc_url(home_url('/contact/')); ?>"><?php esc_html_e('Contact','klaravex-personal'); ?></a></li>
          <li><a href="tel:+14243486010"><i class="ph ph-phone" aria-hidden="true"></i> <?php echo esc_html(kvxp_mod('kvxp_cta_phone','+1 (424) 348-6010')); ?></a></li>
        </ul>
      </div>
    </div>
    <div class="footer-trust">
      <div class="trust-badge"><i class="ph ph-shield-check" aria-hidden="true"></i> <?php esc_html_e('Cyber Insured — $1M Coverage','klaravex-personal'); ?></div>
      <div class="trust-badge"><i class="ph ph-certificate" aria-hidden="true"></i> <?php esc_html_e('E&O / Professional Liability Insured','klaravex-personal'); ?></div>
      <div class="trust-badge"><i class="ph ph-lock-key" aria-hidden="true"></i> <?php esc_html_e('SOC 2 & HIPAA Readiness Advisory','klaravex-personal'); ?></div>
    </div>
    <div class="footer-bottom">
      <p><?php echo kvxp_mod('kvxp_footer_legal', '&copy; ' . date('Y') . ' Klaravex LLC&trade; &mdash; Personal IT Help'); ?>
        <span class="footer-legal-links">
          <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>"><?php esc_html_e('Privacy Policy','klaravex-personal'); ?></a>
          <span aria-hidden="true">·</span>
          <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>"><?php esc_html_e('Terms of Service','klaravex-personal'); ?></a>
        </span>
      </p>
      <a href="<?php echo esc_url(kvxp_mod('kvxp_biz_url','https://klaravex.com')); ?>" class="footer-biz-link">
        <i class="ph ph-buildings" aria-hidden="true"></i>
        <?php esc_html_e('Business IT Support → klaravex.com','klaravex-personal'); ?>
      </a>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
