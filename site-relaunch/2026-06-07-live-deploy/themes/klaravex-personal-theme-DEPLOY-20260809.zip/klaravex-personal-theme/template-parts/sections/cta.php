<?php
$headline = kvxp_mod('kvxp_cta_headline', "Ready to stop fighting with your tech?");
$btn      = kvxp_mod('kvxp_cta_btn',      'Get Help Today');
$email    = kvxp_mod('kvxp_cta_email',     'hello@klaravex.com');
$phone    = kvxp_mod('kvxp_cta_phone',     '+1 (424) 348-6010');
// Wrap last word in em for gradient effect
$parts = explode(' ', $headline);
$last  = array_pop($parts);
$h_html = implode(' ', $parts) . ' <em>' . $last . '</em>';
?>
<section class="cta-section" id="cta">
  <div class="wrap">
    <div class="cta-inner">
      <h2 class="reveal"><?php echo wp_kses_post($h_html); ?></h2>
      <div class="cta-actions reveal d2">
        <a href="#cta" class="btn-light" data-chat-open="booking">
          <i class="ph ph-chat-circle-text" aria-hidden="true"></i>
          <?php echo esc_html($btn); ?>
        </a>
        <a href="<?php echo esc_url(home_url('/#pricing')); ?>" class="btn-ghost-light">
          <?php esc_html_e('See pricing','klaravex-personal'); ?>
          <i class="ph ph-arrow-right" aria-hidden="true"></i>
        </a>
      </div>
      <div class="cta-alt reveal d3">
        <a href="tel:+14243486010"><i class="ph ph-phone" aria-hidden="true"></i> <?php echo esc_html($phone); ?></a>
        <span class="cta-alt-sep" aria-hidden="true">·</span>
        <a href="mailto:<?php echo esc_attr($email); ?>"><i class="ph ph-envelope-simple" aria-hidden="true"></i> <?php echo esc_html($email); ?></a>
      </div>
    </div>
  </div>
</section>
