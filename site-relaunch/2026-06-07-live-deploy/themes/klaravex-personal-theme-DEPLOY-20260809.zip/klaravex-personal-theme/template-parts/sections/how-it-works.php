<?php
$steps = [
  [ 'num'=>'1', 'title'=>__("Tell us what's wrong",'klaravex-personal'), 'body'=>__("Book online or drop us a message. No ticket forms, no hold music. Just tell us what's happening in your own words.",'klaravex-personal'), 'note'=>__('We respond within a few hours, usually much faster.','klaravex-personal'), 'note_icon'=>'ph-clock' ],
  [ 'num'=>'2', 'title'=>__('We fix it together','klaravex-personal'),   'body'=>__("Remote session via screen share, or in-person if needed. We explain what we're doing as we go — no mystery, no surprises.",'klaravex-personal'), 'note'=>__('Always with your permission. You stay in control.','klaravex-personal'), 'note_icon'=>'ph-shield-check' ],
  [ 'num'=>'3', 'title'=>__('You feel confident','klaravex-personal'),   'body'=>__("We don't just fix it and leave. We make sure you understand what happened and what to do if it comes up again.",'klaravex-personal'), 'note'=>__('Written summary of everything we did — sent to you after every session.','klaravex-personal'), 'note_icon'=>'ph-notepad' ],
];
?>
<section class="how-section" id="how">
  <div class="wrap">
    <div class="eyebrow reveal"><?php esc_html_e('How it works','klaravex-personal'); ?></div>
    <h2 class="section-h reveal d1"><?php esc_html_e('Three steps to sorted.','klaravex-personal'); ?></h2>
    <p class="section-sub reveal d2"><?php esc_html_e("No tech knowledge needed. No jargon. Just someone who speaks your language and fixes your problem.",'klaravex-personal'); ?></p>
    <div class="how-steps">
      <?php foreach ($steps as $i => $step) : ?>
        <div class="how-step reveal d<?php echo $i+1; ?>">
          <div class="how-step-num" aria-hidden="true"><?php echo esc_html($step['num']); ?></div>
          <h3><?php echo esc_html($step['title']); ?></h3>
          <p><?php echo esc_html($step['body']); ?></p>
          <div class="how-step-note">
            <i class="ph <?php echo esc_attr($step['note_icon']); ?>" aria-hidden="true"></i>
            <?php echo esc_html($step['note']); ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
