<?php
$testimonials = [
  [ 'quote'=>__("My mum couldn't video call us without something going wrong. After one session with Klaravex, she's doing it herself every Sunday. I nearly cried.",'klaravex-personal'), 'name'=>'Sarah K.', 'role'=>__('Family &amp; Senior Tech','klaravex-personal'), 'initial'=>'S', 'color'=>'#4F46E5' ],
  [ 'quote'=>__("I'd been putting off sorting my passwords and privacy settings for two years. We did it in an hour. I actually understand what was changed and why.",'klaravex-personal'), 'name'=>'Raj M.', 'role'=>__('Privacy &amp; Security','klaravex-personal'), 'initial'=>'R', 'color'=>'#10B981' ],
  [ 'quote'=>__("I started using AI tools for my freelance work after my coaching session. Honestly saved me hours every week. Wish I'd done it sooner.",'klaravex-personal'), 'name'=>'Jamie T.', 'role'=>__('AI Skills Coaching','klaravex-personal'), 'initial'=>'J', 'color'=>'#F59E0B' ],
];
?>
<section class="testimonials-section" id="reviews">
  <div class="wrap">
    <div class="eyebrow reveal"><?php esc_html_e('What people say','klaravex-personal'); ?></div>
    <h2 class="section-h reveal d1"><?php esc_html_e('Real people, real results.','klaravex-personal'); ?></h2>
    <p class="section-sub reveal d2"><?php esc_html_e('No jargon and no rush. Just someone who genuinely helped.','klaravex-personal'); ?></p>
    <div class="testimonials-grid">
      <?php foreach ($testimonials as $i => $t) : ?>
        <div class="testimonial-card reveal d<?php echo $i+1; ?>">
          <div class="t-stars" aria-label="<?php esc_attr_e('5 stars','klaravex-personal'); ?>">★★★★★</div>
          <p class="t-quote"><?php echo esc_html($t['quote']); ?></p>
          <div class="t-author">
            <div class="t-avatar" style="background:<?php echo esc_attr($t['color']); ?>;" aria-hidden="true"><?php echo esc_html($t['initial']); ?></div>
            <div>
              <div class="t-name"><?php echo esc_html($t['name']); ?></div>
              <div class="t-role"><?php echo wp_kses_post($t['role']); ?></div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
