<?php
$badge    = kvxp_mod('kvxp_hero_badge',    'Real help from real experts');
$headline = kvxp_mod('kvxp_hero_headline', 'Tech that <em>actually</em> works for you.');
$sub      = kvxp_mod('kvxp_hero_sub',      "Plain English. No jargon. No judgment. Whether it's fixing a frustrating problem, protecting your family online, or finally learning to use AI — we've got you.");
$cta      = kvxp_mod('kvxp_hero_cta',      'Get Help Today');
$proof    = kvxp_mod('kvxp_hero_proof',    'Loved by 500+ people');
?>
<section class="hero" id="home">
  <div class="hero-photo" role="img" aria-label="<?php esc_attr_e('Friendly tech help','klaravex-personal'); ?>"></div>
  <div class="hero-orb-1" aria-hidden="true"></div>
  <div class="hero-orb-2" aria-hidden="true"></div>
  <div class="wrap">
    <div class="hero-body">
      <?php if ($badge) : ?>
        <div class="hero-badge reveal">
          <i class="ph ph-sparkle" aria-hidden="true"></i>
          <?php echo esc_html($badge); ?>
        </div>
      <?php endif; ?>
      <h1 class="reveal d1"><?php echo wp_kses_post($headline); ?></h1>
      <p class="hero-sub reveal d2"><?php echo esc_html($sub); ?></p>
      <div class="hero-actions reveal d3">
        <a href="#cta" class="btn-indigo"><i class="ph ph-chat-circle-text" aria-hidden="true"></i><?php echo esc_html($cta); ?></a>
        <a href="#services" class="btn-outline"><?php esc_html_e('See what we help with','klaravex-personal'); ?> <i class="ph ph-arrow-right" aria-hidden="true"></i></a>
      </div>
      <div class="hero-social-proof reveal d4">
        <div class="hero-avatars" aria-hidden="true">
          <div class="hero-avatar av1">M</div>
          <div class="hero-avatar av2">S</div>
          <div class="hero-avatar av3">R</div>
          <div class="hero-avatar av4">J</div>
        </div>
        <div class="hero-proof-text">
          <strong><?php echo esc_html($proof); ?></strong>
          <span class="hero-stars">★★★★★</span> <?php esc_html_e('4.9 average rating','klaravex-personal'); ?>
        </div>
      </div>
    </div>
  </div>
</section>
