<?php
/**
 * Klaravex Personal Theme — functions.php
 */
defined('ABSPATH') || exit;

define('KVXP_VERSION', '1.0.0');
define('KVXP_DIR', get_template_directory());
define('KVXP_URI', get_template_directory_uri());

/* ── SETUP ── */
function kvxp_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', [ 'height' => 60, 'width' => 200, 'flex-height' => true, 'flex-width' => true ]);
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','script','style']);
    add_theme_support('responsive-embeds');
    add_image_size('kvxp-hero',     1920, 1080, true);
    add_image_size('kvxp-card',      800,  600, true);
    register_nav_menus([
        'primary' => __('Primary Navigation', 'klaravex-personal'),
        'footer'  => __('Footer Navigation',  'klaravex-personal'),
    ]);
}
add_action('after_setup_theme', 'kvxp_setup');

/* ── ENQUEUE ── */
function kvxp_assets() {
    wp_enqueue_style('kvxp-fonts',
        'https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Inter:wght@400;500;600&display=swap',
        [], null);
    wp_enqueue_script('phosphor-icons',
        'https://unpkg.com/@phosphor-icons/web@2.1.1/src/index.js',
        [], '2.1.1', true);
    wp_enqueue_style('kvxp-main',   KVXP_URI.'/assets/css/main.css', ['kvxp-fonts'], KVXP_VERSION);
    wp_enqueue_script('kvxp-main',  KVXP_URI.'/assets/js/main.js',  [], KVXP_VERSION, true);
    wp_localize_script('kvxp-main', 'kvxpData', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('kvxp_nonce'),
    ]);
}
add_action('wp_enqueue_scripts', 'kvxp_assets');

/* ── CUSTOMIZER ── */
function kvxp_customizer($wp_customize) {
    $wp_customize->add_panel('kvxp_panel', [ 'title' => __('Klaravex Personal', 'klaravex-personal'), 'priority' => 30 ]);

    /* Hero */
    $wp_customize->add_section('kvxp_hero', [ 'title' => __('Hero', 'klaravex-personal'), 'panel' => 'kvxp_panel' ]);
    kvxp_text($wp_customize, 'kvxp_hero', 'kvxp_hero_badge',    __('Badge text',   'klaravex-personal'), 'Real help from real experts');
    kvxp_text($wp_customize, 'kvxp_hero', 'kvxp_hero_headline', __('Headline',      'klaravex-personal'), 'Tech that <em>actually</em> works for you.');
    kvxp_text($wp_customize, 'kvxp_hero', 'kvxp_hero_sub',      __('Subheadline',   'klaravex-personal'), "Plain English. No jargon. No judgment.");
    kvxp_text($wp_customize, 'kvxp_hero', 'kvxp_hero_cta',      __('CTA text',      'klaravex-personal'), 'Get Help Today');
    kvxp_text($wp_customize, 'kvxp_hero', 'kvxp_hero_proof',    __('Social proof',  'klaravex-personal'), 'Loved by 500+ people');
    kvxp_image($wp_customize, 'kvxp_hero', 'kvxp_hero_photo',   __('Background photo', 'klaravex-personal'));

    /* Pricing */
    $wp_customize->add_section('kvxp_pricing', [ 'title' => __('Pricing', 'klaravex-personal'), 'panel' => 'kvxp_panel' ]);
    kvxp_text($wp_customize, 'kvxp_pricing', 'kvxp_price_session',  __('One-time session price', 'klaravex-personal'), '$39');
    kvxp_text($wp_customize, 'kvxp_pricing', 'kvxp_price_monthly',  __('Monthly plan price',     'klaravex-personal'), '$29');
    kvxp_text($wp_customize, 'kvxp_pricing', 'kvxp_price_family',   __('Family plan price',      'klaravex-personal'), '$39');

    /* CTA */
    $wp_customize->add_section('kvxp_cta', [ 'title' => __('CTA Strip', 'klaravex-personal'), 'panel' => 'kvxp_panel' ]);
    kvxp_text($wp_customize, 'kvxp_cta', 'kvxp_cta_headline', __('Headline', 'klaravex-personal'), "Ready to stop fighting with your tech?");
    kvxp_text($wp_customize, 'kvxp_cta', 'kvxp_cta_btn',      __('Button text', 'klaravex-personal'), 'Get Help Today');
    kvxp_text($wp_customize, 'kvxp_cta', 'kvxp_cta_email',    __('Contact email', 'klaravex-personal'), 'hello@klaravex.com');

    /* Cross-site */
    $wp_customize->add_section('kvxp_xsite', [ 'title' => __('Cross-site Links', 'klaravex-personal'), 'panel' => 'kvxp_panel' ]);
    kvxp_text($wp_customize, 'kvxp_xsite', 'kvxp_biz_url',   __('Business site URL', 'klaravex-personal'), 'https://klaravex.com');
    kvxp_text($wp_customize, 'kvxp_xsite', 'kvxp_footer_legal', __('Footer legal line', 'klaravex-personal'), '© ' . date('Y') . ' Klaravex LLC — Personal IT Help');
}
add_action('customize_register', 'kvxp_customizer');

function kvxp_text($wpc, $section, $id, $label, $default = '') {
    $wpc->add_setting($id, ['default' => $default, 'sanitize_callback' => 'wp_kses_post']);
    $wpc->add_control($id, ['label' => $label, 'section' => $section, 'type' => 'textarea']);
}
function kvxp_image($wpc, $section, $id, $label) {
    $wpc->add_setting($id, ['default' => '', 'sanitize_callback' => 'esc_url_raw']);
    $wpc->add_control(new WP_Customize_Image_Control($wpc, $id, ['label' => $label, 'section' => $section]));
}

/* ── CUSTOMIZER CSS OUTPUT ── */
function kvxp_customizer_css() {
    $photo = get_theme_mod('kvxp_hero_photo');
    if ($photo) : ?>
    <style>.hero-photo { --hero-photo-url: url('<?php echo esc_url($photo); ?>'); }</style>
    <?php endif;
}
add_action('wp_head', 'kvxp_customizer_css');

/* ── HELPER ── */
function kvxp_mod($key, $fallback = '') {
    return wp_kses_post(get_theme_mod($key, $fallback));
}

/* ── DISABLE USERS SITEMAP (no author archives) ── */
add_filter('wp_sitemaps_add_provider', function($provider, $name) {
    return ($name === 'users') ? false : $provider;
}, 10, 2);

/* ── CONTACT FORM AJAX ── */
function kvxp_handle_contact() {
    check_ajax_referer('kvxp_nonce', 'nonce');
    $name    = sanitize_text_field($_POST['name']    ?? '');
    $email   = sanitize_email($_POST['email']        ?? '');
    $service = sanitize_text_field($_POST['service'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');
    if (empty($name) || !is_email($email)) {
        wp_send_json_error(['message' => 'Please fill in your name and a valid email address.']);
    }
    $to      = get_option('admin_email');
    $subject = "New enquiry from {$name}" . ($service ? " — {$service}" : '');
    $body    = "Name: {$name}\nEmail: {$email}\nService: {$service}\n\nMessage:\n{$message}";
    $headers = ['Content-Type: text/plain; charset=UTF-8', "Reply-To: {$name} <{$email}>"];
    wp_mail($to, $subject, $body, $headers);
    wp_send_json_success(['message' => "Thanks {$name}! We'll be in touch shortly."]);
}
add_action('wp_ajax_kvxp_contact',        'kvxp_handle_contact');
add_action('wp_ajax_nopriv_kvxp_contact', 'kvxp_handle_contact');
